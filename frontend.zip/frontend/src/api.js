import axios from "axios";

const api = axios.create({ baseURL: import.meta.env.VITE_API_URL || "http://localhost:8000" });

api.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

export function errMsg(e) {
  const d = e.response?.data?.detail;
  if (typeof d === "string") return d;
  if (Array.isArray(d)) return d.map((x) => x.msg).join(". ");
  return "No se pudo conectar con el servidor";
}

export const fmtDate = (s) =>
  new Date(s).toLocaleDateString("es", { day: "numeric", month: "short", year: "numeric" });

export const fmtViews = (n) => `${n} ${n === 1 ? "vista" : "vistas"}`;

export default api;
