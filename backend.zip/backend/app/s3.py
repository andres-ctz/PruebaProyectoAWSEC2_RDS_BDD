"""Subida y borrado en S3. Sin llaves: boto3 toma las credenciales del IAM Role de la EC2."""
import uuid
from urllib.parse import unquote, urlparse

import boto3

from app.config import settings

_client = None


def client():
    global _client
    if _client is None:
        _client = boto3.client("s3", region_name=settings.aws_region)
    return _client


def upload_file(fileobj, bucket: str, folder: str, content_type: str, ext: str) -> str:
    """Sube un archivo y devuelve su URL pública."""
    key = f"{folder}/{uuid.uuid4()}.{ext}"
    client().upload_fileobj(fileobj, bucket, key, ExtraArgs={"ContentType": content_type})
    return f"https://{bucket}.s3.{settings.aws_region}.amazonaws.com/{key}"


def delete_by_url(bucket: str, url: str) -> None:
    key = unquote(urlparse(url).path.lstrip("/"))
    if key:
        client().delete_object(Bucket=bucket, Key=key)
